# AI YouTube Manager V14 — Play Store preparation

Android Studio project with a native WebView shell.

## Current status
- Builds as a basic Android app once Android SDK/Gradle dependencies are available.
- Package: `com.aiyoutubemanager`
- targetSdk: 35
- versionCode: 14
- versionName: 1.0.14
- Release signing is intentionally not included; create your own upload keystore.
- YouTube OAuth and real AI/backend functionality are not implemented in this demo shell.

## Generate Play Store AAB
Android Studio → Build → Generate Signed Bundle / APK → Android App Bundle → create/select a release keystore.

Before publishing, complete Play Console app content: store listing, privacy policy URL, Data safety, content rating, target audience, app access/login instructions if applicable, and testing requirements.
