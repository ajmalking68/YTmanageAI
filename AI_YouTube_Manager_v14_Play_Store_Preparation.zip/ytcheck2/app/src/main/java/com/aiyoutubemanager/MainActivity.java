package com.aiyoutubemanager;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient());
        webView.loadDataWithBaseURL(null, html(), "text/html", "UTF-8", null);
    }

    private String html() {
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"+
        "<style>body{font-family:sans-serif;background:#0f1115;color:#fff;margin:0;padding:24px}h1{font-size:26px}p{color:#b9bec9;line-height:1.5}.card{background:#191c23;border-radius:16px;padding:18px;margin-top:16px}button{width:100%;padding:14px;border:0;border-radius:12px;background:#ff0033;color:#fff;font-weight:700;margin-top:10px}</style></head>"+
        "<body><h1>AI YouTube Manager</h1><p>Manage your YouTube workflow from one place.</p>"+
        "<div class='card'><h2>Dashboard</h2><p>Connect your YouTube channel to start. This release is a UI/demo shell; YouTube OAuth and AI backend are not connected yet.</p><button onclick=\"alert('YouTube connection will be enabled in a future release.')\">Connect YouTube</button></div>"+
        "<div class='card'><h2>Privacy</h2><p>This demo does not collect or transmit personal data from the local interface.</p></div></body></html>";
    }

    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
